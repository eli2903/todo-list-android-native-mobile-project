
    $(document).ready(function () {
        setGreeting();
    })

function setGreeting(){
    var user = window.c1.getUserGreeting();
    var x = document.getElementById('greetingUser');
    x.textContent = "  Hello "+ user;
}
function getFromDB(){
     /*
     1) before createlistgui() , erase all content and display list from db.
     2) In order to avoid displaying the list on every click
     */
        $('#theContent').empty();
        window.c1.PrintToDo();

}

    function createListOnGUI(ID,TaskName,DueDate,Description) {

        var div = '<div data-role="collapsible" data-inset="true" data-iconpos="right" id=task'+ID+'><h3>'+TaskName+'</h3></div>';
        var list= '<ul data-role="listview" data-inset="true" data-theme="c" id="list" />';

        var li ='<p id=taskName'+ID+'>'+TaskName+'</p>';
        list = $(list).append(li);
        li = '<p id=due'+ID+'>'+DueDate+'</p>';
        list = $(list).append(li);
        li = '<p id=des'+ID+'>'+Description+'</p>';
        list = $(list).append(li);



        var div2='<a href="#Edit'+ID+'" data-rel="popup" data-position-to="window" data-transition="pop" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-icon-gear ui-btn-icon-left ui-btn-b" >Edit</a>';
        div2 +='<a href="#Delete'+ID+'" data-rel="popup" data-position-to="window" data-transition="pop" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-icon-delete ui-btn-icon-left ui-btn-b" onclick="deleteTask('+ID+')">delete</a>';
        div2 += '<div data-role="popup" id="Edit'+ID+'" data-overlay-theme="a" data-theme="a" data-dismissible="false" style="max-width:400px;">';

        div2 += '<div role="main" class="ui-content">';
        div2 += '<h2>'+TaskName+'</h2>';
        div2 += '<input type="text"  id ="taskNameToUpdate'+ID+'" value="'+TaskName+'">';
        div2 += '<input type="text"  id ="dueDateToUpdate'+ID+'" value="'+DueDate+'">';
        div2 += '<input type="text"  id ="descriptionToUpdate'+ID+'" value="'+Description+'">';
        div2 += '<a href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-a" data-rel="back">Cancel</a>';
        div2 += '<a href="#" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-btn-a" data-rel="back" onclick="update('+ID+')">Update</a>'; //send only the parameters to change
        list = $(list).append(div2);

        $(list).appendTo(div).parent().appendTo('[data-role="content"]').end().trigger("create");
        $('div[data-role=collapsible]').collapsible({theme:'d',refresh:true});
        $('[data-role="listview"]').refresh();

    }
       function update(ID){
        alert('updated ');
        var oldTaskName = document.getElementById("taskName"+ID);
        var newTaskName = document.getElementById("taskNameToUpdate"+ID).value;

        oldTaskName.textContent = newTaskName;

        var oldDueDate = document.getElementById("due"+ID);
        var newDueDate = document.getElementById("dueDateToUpdate"+ID).value;

        oldDueDate.textContent = newDueDate;

        var oldDescription = document.getElementById("des"+ID);
        var newDescription = document.getElementById("descriptionToUpdate"+ID).value;

        oldDescription.textContent = newDescription;



        var oldTaskTitle = document.getElementById('task'+ID);
        oldTaskTitle.children[0].children[0].text =newTaskName;


        //call database update function
        window.c1.updateDB(ID,newTaskName,newDueDate,newDescription);
    }
      function addTaskToDB(){

        //1- id auto generated from DB
        //2- return from db with ID
        //3- created task on GUI
        var task = document.getElementById('newTaskInput').value;
        var dueDate = document.getElementById('newDueDateInput').value;
        var description = document.getElementById('newDescriptionInput').value;
        var ID =  window.c1.addTaskToDatabase(task,dueDate,description);

        createListOnGUI(ID,task,dueDate,description);


        }

    function deleteTask(ID){
        //remove from UI
         $('#task'+ID+'').remove();

         //remove from DB
         window.c1.deleteFromDB(ID);
    }

    function deleteAllMyTasks(){
        //delete all from UI
        $('#theContent').empty();

        //delete all from DB
        window.c1.deleteAllMyTasksFromDB();
    }
    function tableIsEmpty(){
        alert('empty db');
}