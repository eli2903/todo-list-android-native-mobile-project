package com.finalproject.eliassaad.facebooklogin;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by eliassaad on 7/10/18.
 */

/*
This is the about activity
the layout is represented by xml file
 */
public class AboutActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_layout);
    }
}
