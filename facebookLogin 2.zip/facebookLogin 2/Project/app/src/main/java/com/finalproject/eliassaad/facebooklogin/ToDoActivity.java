package com.finalproject.eliassaad.facebooklogin;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

/**
 * Created by eliassaad on 7/4/18.
 */

public class ToDoActivity extends Activity {

    WebView view;
    DatabaseHelper myDb;
    /*
        this is the main method that will be executed when the app starts
        - An instance of an external class will be created in order to link between javascript and java methods.
        - using loadUrl method, it is possible to load a fully html page (located in the assets folder)
        - It is necessary to enable javascript
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        theClass c = new theClass();
        myDb = new DatabaseHelper(this);
        view = new WebView(this);
        view.getSettings().setJavaScriptEnabled(true);
        view.addJavascriptInterface(c, "c1");

        view.loadUrl("file:///android_asset/www/indexToDo.html");
        view.setWebChromeClient(new WebChromeClient());
        view.getSettings().setAllowFileAccess(true);
        view.getSettings().setAllowUniversalAccessFromFileURLs(true);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(view);

    }
    /*
    Setting external class
    this class will manage the link between javascript and java functions
     */
    class theClass extends WebViewClient {
        @android.webkit.JavascriptInterface
        /*
            this method will print all table data to the GUI
            In case the table is empty ,an alert will be raised to the user (javascript side )
            Otherwise it will display data using the Cursor object while looping through the rows.
         */
        public void  PrintToDo(){
            view.post(new Runnable() {
                @Override
                public void run() {

                    Cursor result = myDb.getAllData();
                    String ID,toDo,Date,Description;
                    int numOfRows= result.getCount();

                    if(numOfRows == 0 ){
                        view.loadUrl("javascript:tableIsEmpty();");
                    }
                    else{
                        while(result.moveToNext()){
                            ID = result.getString(0);
                            toDo = result.getString(1);
                            Date = result.getString(2);
                            Description = result.getString(3);
                            view.loadUrl("javascript:createListOnGUI('"+ID+"','"+toDo+"','"+Date+"','"+Description+"');");
                        }
                    }
                }
            });

        }
        /*
        this function will call the 'updateData' method inside the DatabaseHelper class.
        the last , will update the record using the UNIQUE id
         */
        @android.webkit.JavascriptInterface
        public void  updateDB(String id ,String newTask, String newDueDate,String newDescription){
            myDb.updateData(id,newTask,newDueDate,newDescription);
        }
        @android.webkit.JavascriptInterface
        public String  getUserGreeting(){
            String fbFirstName= "";
            fbFirstName = getIntent().getStringExtra("NAME");
            if(fbFirstName == null){
                fbFirstName = "Guest";
            }
            else{
                fbFirstName = getIntent().getStringExtra("NAME");
            }
            Log.d("aaaaaaaaaaaaaaaa","it is "+ fbFirstName);
            return fbFirstName;
        }

      /*
      this method delete task by row id
       */
        @android.webkit.JavascriptInterface
        public void  deleteFromDB(String id){
            myDb.deleteRow(id);
        }
        /*
          this method will erase all records from the table
       */
        @android.webkit.JavascriptInterface
        public void  deleteAllMyTasksFromDB(){
            myDb.deleteAllTableContent();

        }
        /*
            This method add tasks to the table;
            Then, it will send a function back to javascript returning the new record ID .
            In order to get last ID I use the " moveToLast()" method as it always returns the last row.
         */
        @android.webkit.JavascriptInterface
        public String addTaskToDatabase(String taskName,String date,String description){
            Cursor result = myDb.getAllData();
            String ID="";
            myDb.insertData(taskName,date,description);

            result.moveToLast();
            ID = result.getString(0);
            return ID;
        }
    }
}

