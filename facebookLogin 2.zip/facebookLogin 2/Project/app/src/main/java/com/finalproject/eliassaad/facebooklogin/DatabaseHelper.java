package com.finalproject.eliassaad.facebooklogin;

/**
 * Created by eliassaad on 7/6/18.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by eliassaad on 7/2/18.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ToDo.db";
    public static final String TABLE_NAME = "todolist_table_local";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "TODO_NAME";
    public static final String COL_3 = "DUE_DATE";
    public static final String COL_4 = "DESCRIPTION";


    /*
    The DatabaseHelper Constructor
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null , 1);
    }

    /*
    this method get called in order to create a new table in the database
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create TABLE " + TABLE_NAME+ "(ID INTEGER PRIMARY KEY AUTOINCREMENT,TODO_NAME TEXT,DUE_DATE TEXT ,DESCRIPTION TEXT)");
    }

    /*
       When upgrading the application ,  should define old and new versions
       in order to re-create table if needed.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    /*
    Insert data using ContentValues container and then use it within the
    built-in function (insert) of the SQLiteDatabase instance
    This method takes all values than inserts them into the table accordingly
     */
    public boolean insertData(String todoName, String dueDate, String Description){
        SQLiteDatabase db = this.getReadableDatabase();  //sqlite db instance
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,todoName);
        contentValues.put(COL_3,dueDate);
        contentValues.put(COL_4,Description);
        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result == -1)
            return false ;
        else
            return true;
    }

    /*
    Using the Cursor , it is possible to loop through the table .
    by executing basic sql command and then return the data as a cursor object;
     */
    public Cursor getAllData(){
        SQLiteDatabase db = this.getReadableDatabase(); //create database and table
        Cursor res = db.rawQuery("Select * from "+TABLE_NAME,null);
        return res;
    }
    public boolean updateData(String id , String task,String dueDate,String description){
        SQLiteDatabase db = this.getReadableDatabase(); //sqlite db instance
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,id);
        contentValues.put(COL_2,task);
        contentValues.put(COL_3,dueDate);
        contentValues.put(COL_4,description);
        db.update(TABLE_NAME,contentValues,"id=?",new String[]{id});
        return true;
    }
    public boolean deleteRow(String id){
        SQLiteDatabase db = this.getReadableDatabase(); //sqlite db instance
        db.delete(TABLE_NAME,"id=?",new String[]{id});
        return true;
    }
    public boolean deleteAllTableContent(){
        SQLiteDatabase db = this.getReadableDatabase(); //sqlite db instance
        db.execSQL("DELETE FROM "+TABLE_NAME);
        return true;
    }
}
